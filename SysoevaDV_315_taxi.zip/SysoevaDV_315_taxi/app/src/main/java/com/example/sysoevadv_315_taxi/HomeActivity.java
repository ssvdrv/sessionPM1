package com.example.sysoevadv_315_taxi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
    public  void goNext(View v){
        Intent intent = new Intent(this, CreateActivity.class);
        startActivity(intent);
    }

    public  void goNext1(View v){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
}