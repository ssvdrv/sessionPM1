﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace sysoeva_PR315_pawnshop
{
    class DataBase
    {
        SqlConnection con = new SqlConnection(@"Data Source=10.111.105.2,1433\SQLEXPRESS;Initial Catalog=Sysoeva_PR315_pawnshop;User ID=15-21;Password=***********");

        public void openConnection() 
        {
            if(con.State == System.Data.ConnectionState.Closed)
            {
                con.Open();
            }
        }

        public void closeConnection()
        {
            if (con.State == System.Data.ConnectionState.Open)
            {
                con.Close();
            }
        }

        public SqlConnection GetConnection()
        {
            return con;
        }
    }
}
