﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace sysoeva_PR315_pawnshop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DataBase database = new DataBase();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            textbox_login.Clear();
            textbox_password.Clear();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            var loginUser = textbox_login.Text;
            var passUser = textbox_password.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataGrid table = new DataGrid();
            string querystring = $"select id_employee, login_employee, password_employee from Employee where login_employee = '{loginUser}'and password_employee = '{passUser}' ";
            SqlCommand command = new SqlCommand(querystring, database.GetConnection());
            adapter.SelectCommand = command;
            System.Data.DataSet dataSet = null;
            adapter.Fill(dataSet);
            if (DataObjectSettingDataEventArgs.table.Count ==1)
            {
                MessageBox.Show("Успешный вход","Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Аккаунта не существует", "Аккаунта не существует", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
